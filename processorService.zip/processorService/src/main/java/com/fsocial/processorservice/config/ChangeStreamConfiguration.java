package com.fsocial.processorservice.config;

import com.fsocial.processorservice.services.async.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ChangeStreamConfiguration {

    @Autowired
    PostService postService;
    @Bean
    public void changeStreamPost(){
        try{
            postService.postChangStream();
        }catch (Exception e){
            System.out.println(e.getMessage());;
        }
    }

}
