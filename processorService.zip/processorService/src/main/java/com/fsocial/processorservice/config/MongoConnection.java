package com.fsocial.processorservice.config;

public class MongoConnection {
}
