package com.fsocial.processorservice.services;

public interface AccountServices {
}
