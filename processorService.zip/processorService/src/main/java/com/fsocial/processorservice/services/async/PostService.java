package com.fsocial.processorservice.services.async;

import com.mongodb.MongoClientSettings;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;
import org.bson.conversions.Bson;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.util.List;

import static java.util.Collections.singletonList;
import static javax.management.Query.match;
import static org.bson.codecs.configuration.CodecRegistries.fromProviders;
import static org.bson.codecs.configuration.CodecRegistries.fromRegistries;

@Service
public class PostService {
    private final MongoTemplate mongoTemplate;

    public PostService(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void postChangStream() {
        CodecRegistry pojoCodecRegistry = fromRegistries(MongoClientSettings.getDefaultCodecRegistry(),
                fromProviders(PojoCodecProvider.builder().automatic(true).build()));
        MongoCollection<VendorProducts> vendorCollection = mongoTemplate.getDb().withCodecRegistry(pojoCodecRegistry).getCollection("vendor_products", VendorProducts.class);
        List<Bson> pipeline = singletonList(match(eq("operationType", "insert")));
        oldEcomFieldsCollection.watch(pipeline).forEach(s ->
                mergeFieldsVendorToProducts(s.getDocumentKey().get("_id").asString().getValue())
        );
    }
}
