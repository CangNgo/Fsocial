package com.cangngo.processorservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProcessorServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
